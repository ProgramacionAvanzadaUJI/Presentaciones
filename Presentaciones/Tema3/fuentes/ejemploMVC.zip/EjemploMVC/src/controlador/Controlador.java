package controlador;

public interface Controlador {
    void anyadeEntrada();
    void adelante();
    void atras();
}
package modelo;

public interface CambioModelo {
    void anyadeEntrada(String entrada);
    void incrementaPosicionActual();
    void decrementaPosicionActual();
}

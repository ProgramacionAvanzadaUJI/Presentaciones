package modelo;

public interface InterrogaModelo {
    int getNumeroEntradas();
    String getEntradaActual();
    int getPoscionEntradaActual();
}

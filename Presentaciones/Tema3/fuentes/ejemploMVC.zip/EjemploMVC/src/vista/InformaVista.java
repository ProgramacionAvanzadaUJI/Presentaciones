package vista;

public interface InformaVista {
	void entradaActualCambiada();
	void nuevaEntrada();
}

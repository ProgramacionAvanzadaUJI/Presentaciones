package vista;

public interface InterrogaVista {
	String getEntrada();
}
